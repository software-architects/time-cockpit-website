﻿using Prism41Sample.CustomerMaintenance.ViewModel;
using System;
using System.ComponentModel.Composition;
using System.Windows.Controls;

namespace Prism41Sample.CustomerMaintenance.View
{
    public partial class CustomerDetail : UserControl
    {
        [ImportingConstructor]
        public CustomerDetail(CustomerDetailViewModel viewModel)
        {
            this.InitializeComponent();
            this.DataContext = viewModel;
        }
    }
}
