﻿using Prism41Sample.Infrastructure;
using Prism41Sample.UI.CustomerMaintenance.ViewModel;
using System.ComponentModel.Composition;
using System.Windows.Controls;

namespace Prism41Sample.CustomerMaintenance.View
{
    public partial class CustomerList : UserControl
    {
        [ImportingConstructor]
        public CustomerList(CustomerListViewModel viewModel)
        {
            InitializeComponent();
            this.DataContext = viewModel;
        }
    }
}
