﻿using Microsoft.Practices.Prism;
using Microsoft.Practices.Prism.Commands;
using Microsoft.Practices.Prism.Regions;
using Microsoft.Practices.Prism.ViewModel;
using Prism41Sample.Infrastructure;
using Prism41Sample.Infrastructure.Model;
using System;
using System.ComponentModel.Composition;
using System.Diagnostics;
using System.Linq;

namespace Prism41Sample.CustomerMaintenance.ViewModel
{
    [Export]
    public class CustomerDetailViewModel 
    {
        public CustomerDetailViewModel()
        {
        }
    }
}
