﻿using Microsoft.Practices.Prism.Events;
using Microsoft.Practices.Prism.ViewModel;
using Prism41Sample.CustomerMaintenance;
using Prism41Sample.Infrastructure;
using Prism41Sample.Infrastructure.Model;
using System.Collections.Generic;
using System.ComponentModel.Composition;

namespace Prism41Sample.UI.CustomerMaintenance.ViewModel
{
    [Export]
    public class CustomerListViewModel 
    {
    }
}
