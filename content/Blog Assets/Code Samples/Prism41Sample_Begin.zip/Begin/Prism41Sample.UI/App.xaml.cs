﻿using System.Windows;

namespace Prism41Sample.UI
{
    public partial class App : Application
    {
    }
}
