﻿using Prism41Sample.UI.ViewModel;
using System.ComponentModel.Composition;
using System.Windows;

namespace Prism41Sample.UI.View
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            this.DataContext = new MainWindowViewModel();
        }
    }
}
