﻿using Microsoft.Practices.Prism.Commands;
using Microsoft.Practices.Prism.Regions;
using Microsoft.Practices.Prism.ViewModel;
using Prism41Sample.Infrastructure;
using System;
using System.ComponentModel.Composition;
using System.Windows.Input;

namespace Prism41Sample.UI.ViewModel
{
    [Export]
    public class MainWindowViewModel : NotificationObject
    {
        public MainWindowViewModel()
        {
        }
    }
}
