﻿using Microsoft.Practices.Prism.Commands;
using Microsoft.Practices.Prism.Events;
using Microsoft.Practices.Prism.Modularity;
using Prism41Sample.Infrastructure;
using System.ComponentModel.Composition;
using System.Windows.Input;

namespace Prism41Sample.UI.ViewModel
{
    [Export]
    public class ModulePresenterControlViewModel
    {
        [Import]
        private IModuleCatalog moduleCatalog = null;

        [Import]
        private IEventAggregator eventAggregator = null;

        private readonly DelegateCommand<string> activateModuleCommand = null;

        public ModulePresenterControlViewModel()
        {
            this.activateModuleCommand = new DelegateCommand<string>(
                moduleName => this.eventAggregator.GetEvent<ActivateModuleEvent>().Publish(moduleName));
        }

        public IModuleCatalog ModuleCatalog
        {
            get { return this.moduleCatalog; }
        }

        public ICommand ActivateModuleCommand
        {
            get { return this.activateModuleCommand; }
        }
    }
}
