﻿using Microsoft.Practices.Prism;
using Microsoft.Practices.Prism.Events;
using Microsoft.Practices.Prism.MefExtensions.Modularity;
using Microsoft.Practices.Prism.Modularity;
using Microsoft.Practices.Prism.Regions;
using Microsoft.Practices.ServiceLocation;
using Prism41Sample.CustomerMaintenance.View;
using Prism41Sample.Infrastructure;
using System;
using System.ComponentModel.Composition;

namespace Prism41Sample.CustomerMaintenance
{
    [ModuleExport("CustomerMaintenanceModule", typeof(CustomerMaintenanceModule), DependsOnModuleNames = new[] { "RepositoryModule" })]
    public class CustomerMaintenanceModule : IModule
    {
        [Import]
        private IServiceLocator serviceLocator = null;

        [Import]
        private IRegionManager regionManager = null;

        public void Initialize()
        {
            regionManager.RegisterViewWithRegion(
                RegionAndModuleStringConstants.OverviewRegionName, 
                () => this.serviceLocator.GetInstance<CustomerList>());
        }
    }
}
