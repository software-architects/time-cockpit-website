﻿using Prism41Sample.CustomerMaintenance.ViewModel;
using System;
using System.ComponentModel.Composition;
using System.Windows.Controls;

namespace Prism41Sample.CustomerMaintenance.View
{
    [Export("CustomerDetail")]
    [PartCreationPolicy(CreationPolicy.NonShared)]
    public partial class CustomerDetail : UserControl, IDisposable
    {
        private CustomerDetailViewModel viewModel;

        [ImportingConstructor]
        public CustomerDetail(CustomerDetailViewModel viewModel)
        {
            InitializeComponent();
            this.DataContext = this.viewModel = viewModel;
        }

        ~CustomerDetail()
        {
            this.Dispose(false);
        }

        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        private void Dispose(bool disposing)
        {
            if (disposing)
            {
                this.viewModel.Dispose();
            }
        }
    }
}
