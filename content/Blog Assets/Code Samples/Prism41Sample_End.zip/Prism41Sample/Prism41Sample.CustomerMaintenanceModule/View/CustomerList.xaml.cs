﻿using Prism41Sample.Infrastructure;
using Prism41Sample.UI.CustomerMaintenance.ViewModel;
using System.ComponentModel.Composition;
using System.Windows.Controls;

namespace Prism41Sample.CustomerMaintenance.View
{
    /// <summary>
    /// Interaction logic for CustomerList.xaml
    /// </summary>
    [Export]
    [PartCreationPolicy(CreationPolicy.NonShared)]
    public partial class CustomerList : UserControl
    {
        [ImportingConstructor]
        public CustomerList(CustomerListViewModel viewModel)
        {
            InitializeComponent();
            this.DataContext = viewModel;
        }
    }
}
