﻿using Microsoft.Practices.Prism;
using Microsoft.Practices.Prism.Commands;
using Microsoft.Practices.Prism.Regions;
using Microsoft.Practices.Prism.ViewModel;
using Prism41Sample.Infrastructure;
using Prism41Sample.Infrastructure.Model;
using System;
using System.ComponentModel.Composition;
using System.Diagnostics;
using System.Linq;

namespace Prism41Sample.CustomerMaintenance.ViewModel
{
    [Export]
    [PartCreationPolicy(CreationPolicy.NonShared)]
    public class CustomerDetailViewModel : NotificationObject, ITitledViewModel, INavigationAware, IActiveAware, IDisposable
    {
        private RepositoryBase repository = null;
        private IGlobalCommands globalCommands;
        private DelegateCommand saveAllCommand;
        private DelegateCommand printCommand;

        [ImportingConstructor]
        public CustomerDetailViewModel(RepositoryBase repository, IGlobalCommands globalCommands)
        {
            this.repository = repository;
            this.globalCommands = globalCommands;

            this.globalCommands.RegisterSaveAllCommand(this.saveAllCommand = new DelegateCommand(
                () => Debug.WriteLine("Saving Customer {0}", this.SelectedCustomer.CustomerNumber)));
            this.globalCommands.RegisterPrintActiveItemCommand(this.printCommand = new DelegateCommand(
                () => Debug.WriteLine("Printing Customer {0}", this.SelectedCustomer.CustomerNumber)));
        }

        ~CustomerDetailViewModel()
        {
            this.Dispose(false);
        }

        private Customer SelectedCustomerValue = default(Customer);
        public Customer SelectedCustomer
        {
            get { return this.SelectedCustomerValue; }
            set
            {
                if (this.SelectedCustomerValue != value)
                {
                    this.SelectedCustomerValue = value;
                    this.RaisePropertyChanged(() => this.SelectedCustomer);
                    this.RaisePropertyChanged(() => this.Title);
                }
            }
        }

        public string Title
        {
            get { return this.SelectedCustomer.CustomerNumber.ToString(); }
        }

        public bool IsNavigationTarget(NavigationContext navigationContext)
        {
            return this.GetCustomerNumberFromParameters(navigationContext) == this.SelectedCustomer.CustomerNumber;
        }

        public void OnNavigatedFrom(NavigationContext navigationContext)
        {
        }

        public void OnNavigatedTo(NavigationContext navigationContext)
        {
            this.SelectedCustomer = this.repository
                .Customers
                .Where(c => c.CustomerNumber == this.GetCustomerNumberFromParameters(navigationContext))
                .FirstOrDefault();
        }

        private int GetCustomerNumberFromParameters(NavigationContext navigationContext)
        {
            return Int32.Parse(navigationContext.Parameters["CustomerNumber"]);
        }

        private bool IsActiveValue = default(bool);
        public bool IsActive
        {
            get { return this.IsActiveValue; }
            set
            {
                if (this.IsActiveValue != value)
                {
                    this.IsActiveValue = value;
                    this.printCommand.IsActive = this.IsActive;
                    this.RaisePropertyChanged(() => this.IsActive);
                    if (this.IsActiveChanged != null)
                    {
                        this.IsActiveChanged(this, new EventArgs());
                    }
                }
            }
        }

        public event EventHandler IsActiveChanged;

        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        private void Dispose(bool disposing)
        {
            if (disposing)
            {
                this.globalCommands.UnregisterSaveAllCommand(this.saveAllCommand);
                this.globalCommands.UnregisterPrintActiveItemCommand(this.printCommand);
            }
        }
    }
}
