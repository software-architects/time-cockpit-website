﻿using Microsoft.Practices.Prism.Events;
using Microsoft.Practices.Prism.ViewModel;
using Prism41Sample.CustomerMaintenance;
using Prism41Sample.Infrastructure;
using Prism41Sample.Infrastructure.Model;
using System.Collections.Generic;
using System.ComponentModel.Composition;

namespace Prism41Sample.UI.CustomerMaintenance.ViewModel
{
    [Export]
    [PartCreationPolicy(CreationPolicy.NonShared)]
    public class CustomerListViewModel : NotificationObject
    {
        [Import]
        private IEventAggregator eventAggregator = null;

        private RepositoryBase repository = null;

        [ImportingConstructor]
        public CustomerListViewModel(RepositoryBase repository)
        {
            this.repository = repository;
            this.Customers = this.repository.Customers;
        }

        private Customer SelectedCustomerValue = default(Customer);
        public Customer SelectedCustomer
        {
            get { return this.SelectedCustomerValue; }
            set
            {
                if (this.SelectedCustomerValue != value)
                {
                    this.SelectedCustomerValue = value;
                    this.RaisePropertyChanged(() => this.SelectedCustomer);
                    this.eventAggregator.GetEvent<ActivateCustomerEvent>().Publish(this.SelectedCustomer.CustomerNumber);
                }
            }
        }

        public IEnumerable<Customer> Customers { get; private set; }
    }
}
