﻿using Microsoft.Practices.Prism.Events;

namespace Prism41Sample.Infrastructure
{
    public class ActivateModuleEvent : CompositePresentationEvent<string>
    {
    }
}
