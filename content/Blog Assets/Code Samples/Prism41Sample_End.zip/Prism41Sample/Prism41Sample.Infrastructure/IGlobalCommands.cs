﻿using System.Windows.Input;

namespace Prism41Sample.Infrastructure
{
    public interface IGlobalCommands
    {
        void RegisterSaveAllCommand(ICommand subCommand);
        void UnregisterSaveAllCommand(ICommand subCommand);

        void RegisterPrintActiveItemCommand(ICommand subCommand);
        void UnregisterPrintActiveItemCommand(ICommand subCommand);
    }
}
