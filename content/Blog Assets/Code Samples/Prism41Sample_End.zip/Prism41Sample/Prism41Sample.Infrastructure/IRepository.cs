﻿using Prism41Sample.Infrastructure.Model;
using System.Collections.Generic;
using System.Diagnostics;

namespace Prism41Sample.Infrastructure
{
    public abstract class RepositoryBase 
    {
        public abstract IEnumerable<Customer> Customers { get; }

        public virtual void SaveChanges()
        {
            Debug.WriteLine("Saving changes...");
        }
    }
}
