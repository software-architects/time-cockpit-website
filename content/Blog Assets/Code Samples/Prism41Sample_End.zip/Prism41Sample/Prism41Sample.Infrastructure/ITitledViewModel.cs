﻿using System.ComponentModel;

namespace Prism41Sample.Infrastructure
{
    public interface ITitledViewModel : INotifyPropertyChanged
    {
        string Title { get; }
    }
}
