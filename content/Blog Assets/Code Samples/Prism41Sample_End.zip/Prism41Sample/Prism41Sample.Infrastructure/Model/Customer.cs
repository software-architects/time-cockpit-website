﻿using Microsoft.Practices.Prism.ViewModel;
using System;

namespace Prism41Sample.Infrastructure.Model
{
    /// <summary>
    /// Data entity representing a customer
    /// </summary>
    public class Customer : NotificationObject
    {
        private int CustomerNumberValue = default(int);
        public int CustomerNumber
        {
            get { return this.CustomerNumberValue; }
            set
            {
                if (this.CustomerNumberValue != value)
                {
                    this.CustomerNumberValue = value;
                    this.RaisePropertyChanged(() => this.CustomerNumber);
                }
            }
        }

        private string FirstNameValue = default(string);
        public string FirstName
        {
            get { return this.FirstNameValue; }
            set
            {
                if (this.FirstNameValue != value)
                {
                    this.FirstNameValue = value;
                    this.RaisePropertyChanged(() => this.FirstName);
                }
            }
        }

        private string LastNameValue = default(string);
        public string LastName
        {
            get { return this.LastNameValue; }
            set
            {
                if (this.LastNameValue != value)
                {
                    this.LastNameValue = value;
                    this.RaisePropertyChanged(() => this.LastName);
                }
            }
        }

        private DateTime BirthdayValue = default(DateTime);
        public DateTime Birthday
        {
            get { return this.BirthdayValue; }
            set
            {
                if (this.BirthdayValue != value)
                {
                    this.BirthdayValue = value;
                    this.RaisePropertyChanged(() => this.Birthday);
                }
            }
        }
    }
}
