﻿namespace Prism41Sample.Infrastructure
{
    public static class RegionAndModuleStringConstants
    {
        public const string OverviewRegionName = "CustomerList";
        public const string DetailRegionName = "Detail";
    }
}
