﻿using Prism41Sample.Infrastructure;
using Prism41Sample.Infrastructure.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Prism41Sample.Repository
{
    public class CustomerRepository : RepositoryBase
    {
        private readonly List<Customer> customers = null;
        private readonly ReadOnlyCollection<Customer> readOnlyCustomers = null;
        private readonly string[] firstNames
            = new[] { "Andrew", "Tom", "Max", "Karen", "Michele" };
        private readonly string[] lastNames
            = new[] { "Smith", "Wayne", "Headroom", "Hart", "Simons" };

        public CustomerRepository()
        {
            var rand = new Random();
            this.readOnlyCustomers = new ReadOnlyCollection<Customer>(
                this.customers = Enumerable.Range(1, 20)
                    .Select(i => new Customer
                    {
                        CustomerNumber = i,
                        FirstName = this.firstNames[rand.Next(this.firstNames.Length)],
                        LastName = this.lastNames[rand.Next(this.lastNames.Length)],
                        Birthday = new DateTime(rand.Next(1950, 2000), rand.Next(1, 12), rand.Next(1, 28))
                    })
                    .ToList());
        }

        public override IEnumerable<Customer> Customers
        {
            get { return this.readOnlyCustomers; }
        }
    }
}
