﻿using Microsoft.Practices.Prism.MefExtensions.Modularity;
using Microsoft.Practices.Prism.Modularity;
using Microsoft.Practices.ServiceLocation;
using Prism41Sample.Infrastructure;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;

namespace Prism41Sample.Repository
{
    [ModuleExport("RepositoryModule", typeof(RepositoryModule))]
    public class RepositoryModule : IModule
    {
        [Import]
        private IServiceLocator serviceLocator = null;

        public void Initialize()
        {
            // Publish repository service using MEF
            var container = this.serviceLocator.GetInstance<CompositionContainer>();
            container.ComposeExportedValue<RepositoryBase>(new CustomerRepository());
        }
    }
}
