﻿using System.Windows;

namespace Prism41Sample.UI
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            // Use Prism bootstrapper to launch main window
            base.OnStartup(e);
            (new Bootstrapper()).Run();
        }
    }
}
