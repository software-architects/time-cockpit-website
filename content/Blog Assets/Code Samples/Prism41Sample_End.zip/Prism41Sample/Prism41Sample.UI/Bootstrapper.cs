﻿using Microsoft.Practices.Prism.MefExtensions;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;
using System.IO;
using System.Reflection;
using System.Windows;

namespace Prism41Sample.UI
{
    public class Bootstrapper : MefBootstrapper
    {
        /// <summary>
        /// Sets up MEF catalogs
        /// </summary>
        protected override void ConfigureAggregateCatalog()
        {
            base.ConfigureAggregateCatalog();

            var executingAssembly = Assembly.GetExecutingAssembly();
            // Use current assembly when looking for MEF exports
            this.AggregateCatalog.Catalogs.Add(new AssemblyCatalog(executingAssembly));
            // Look into "Modules" directory to dynamically load additional exports
            this.AggregateCatalog.Catalogs.Add(new DirectoryCatalog(
                Path.Combine(Path.GetDirectoryName(executingAssembly.Location), "RuntimeModules")));
        }

        /// <summary>
        /// Exports MEF container in service locator
        /// </summary>
        protected override CompositionContainer CreateContainer()
        {
            var container = base.CreateContainer();
            container.ComposeExportedValue(container);
            return container;
        }

        protected override DependencyObject CreateShell()
        {
            // Create a new instance of the applications "MainWindow"
            return this.Container.GetExportedValue<Window>("MainWindow");
        }

        /// <summary>
        /// Makes shell the main window of the application.
        /// </summary>
        protected override void InitializeShell()
        {
            base.InitializeShell();

            Application.Current.MainWindow = this.Shell as Window;
            Application.Current.MainWindow.Show();
        }
    }
}
