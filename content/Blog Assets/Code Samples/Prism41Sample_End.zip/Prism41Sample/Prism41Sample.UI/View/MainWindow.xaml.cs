﻿using Prism41Sample.UI.ViewModel;
using System.ComponentModel.Composition;
using System.Windows;

namespace Prism41Sample.UI.View
{
    [Export("MainWindow", typeof(Window))]
    public partial class MainWindow : Window
    {
        [ImportingConstructor]
        public MainWindow(MainWindowViewModel viewModel)
        {
            InitializeComponent();
            this.DataContext = viewModel;
        }
    }
}
