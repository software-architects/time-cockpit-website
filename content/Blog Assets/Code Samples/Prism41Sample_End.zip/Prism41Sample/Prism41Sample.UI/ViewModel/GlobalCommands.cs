﻿using Microsoft.Practices.Prism.Commands;
using Prism41Sample.Infrastructure;
using System.ComponentModel.Composition;
using System.Windows.Input;

namespace Prism41Sample.UI.ViewModel
{
    [Export(typeof(IGlobalCommands))]
    [PartCreationPolicy(CreationPolicy.Shared)]
    public class GlobalCommands : IGlobalCommands
    {
        public GlobalCommands()
        {
            this.SaveAllCommand = new CompositeCommand();
            this.PrintActiveItem = new CompositeCommand(true);
        }

        public CompositeCommand SaveAllCommand { get; private set; }
        public CompositeCommand PrintActiveItem { get; private set; }

        #region IGlobalCommands implementation
        public void RegisterSaveAllCommand(ICommand subCommand)
        {
            this.SaveAllCommand.RegisterCommand(subCommand);
        }

        public void RegisterPrintActiveItemCommand(ICommand subCommand)
        {
            this.PrintActiveItem.RegisterCommand(subCommand);
        }


        public void UnregisterSaveAllCommand(ICommand subCommand)
        {
            this.SaveAllCommand.UnregisterCommand(subCommand);            
        }

        public void UnregisterPrintActiveItemCommand(ICommand subCommand)
        {
            this.PrintActiveItem.UnregisterCommand(subCommand);
        }
        #endregion
    }
}
