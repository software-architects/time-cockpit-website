﻿using Microsoft.Practices.Prism;
using Microsoft.Practices.Prism.Commands;
using Microsoft.Practices.Prism.Events;
using Microsoft.Practices.Prism.Regions;
using Microsoft.Practices.Prism.ViewModel;
using Prism41Sample.Infrastructure;
using System;
using System.ComponentModel.Composition;
using System.Windows.Input;

namespace Prism41Sample.UI.ViewModel
{
    [Export]
    public class MainWindowViewModel : NotificationObject
    {
        private IEventAggregator eventAggregator = null;

        [Import]
        private IRegionManager regionManager = null;

        [ImportingConstructor]
        public MainWindowViewModel(IEventAggregator eventAggregator)
        {
            this.CloseAllTabsCommand = new DelegateCommand(this.OnCloseAllTabs);
            this.eventAggregator = eventAggregator;
            this.eventAggregator.GetEvent<ActivateCustomerEvent>().Subscribe(this.OnActivateCustomer);
        }

        #region Commands
        [Import(typeof(IGlobalCommands))]
        public GlobalCommands GlobalCommands { get; private set; }

        public ICommand CloseAllTabsCommand { get; private set; }
        #endregion

        private void OnCloseAllTabs()
        {
            var detailRegion = this.regionManager.Regions[RegionAndModuleStringConstants.DetailRegionName];
            foreach (var view in detailRegion.Views)
            {
                // if the view implements IDisposable, call Dispose on it
                var disposableView = view as IDisposable;
                if (disposableView != null)
                {
                    disposableView.Dispose();
                }

                detailRegion.Remove(view);
            }
        }

        #region Main window controller
        // You should implement the controller in a separate class if navigation is more complex.

        private void OnActivateCustomer(int customerNumber)
        {
            var q = new UriQuery();
            q.Add("CustomerNumber", customerNumber.ToString());
            this.regionManager.RequestNavigate(
                RegionAndModuleStringConstants.DetailRegionName,
                new Uri("CustomerDetail" + q.ToString(), UriKind.Relative));
        }
        #endregion
    }
}
