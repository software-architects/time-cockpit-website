/// <reference path="Q:/SoftwareArchitects.SessionsAndTrainings/TypeScriptSharedCode/tsd/node-0.8.d.ts" />

var x: string;
x = "Hello World!";

var n: number;
n = 5;

console.log(n.toString());
