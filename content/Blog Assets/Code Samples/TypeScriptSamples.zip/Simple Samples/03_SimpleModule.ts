/// <reference path="Q:/SoftwareArchitects.SessionsAndTrainings/TypeScriptSharedCode/tsd/node-0.8.d.ts" />

module Crm {
	export class Customer {
		constructor(public custName: string) { }
	}
}

module Crm {
	export class Opportunity {
		constructor(public customer: Customer) { }
	}
}

var classesInCrmModule = "";
for(var key in Crm) {
	console.log(key);
}

