/// <reference path="../modules/require.d.ts" />
/// <reference path="AppMain.ts" />

require.config({
    baseUrl: '../',
    paths: {
        'jquery': 'lib/jquery-1.7.2'
    }, 
    shim: {
        jquery: {
            exports: '$'
        }
    }
});

require(['jquery','app/AppMain', 
     ], 
    ($, main) => {
        var appMain = new main.AppMain();
        appMain.run();
});