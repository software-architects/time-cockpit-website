/// <reference path="../modules/jquery-1.8.d.ts" />
import cust = module("app/classes/customer");

export class AppMain {
    public run() {
        $.get("http://localhost:8088/Customer/99").done(function (data) {
            var c = new cust.customer.Customer(JSON.parse(data));
            $("#fullname").text(c.fullName());
        });
    }
}